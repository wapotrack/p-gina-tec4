# CiudadActiva

Aplicacion web municipal donde los vecinos publican buenas acciones hechas por la ciudad, un administrador las verifica y cada accion aprobada otorga puntos canjeables por beneficios en comercios adheridos.

Proyecto escolar. Frontend estatico en HTML y CSS.

## Estado

Maquetado completo de las 13 pantallas con datos de ejemplo. Todavia sin JavaScript ni conexion a la API.

## Pantallas

| Archivo | Descripcion |
|---|---|
| `index.html` | Feed publico de acciones aprobadas |
| `login.html` | Inicio de sesion |
| `registro.html` | Alta de vecino |
| `nueva-accion.html` | Formulario de publicacion con subida de pruebas |
| `mis-acciones.html` | Acciones propias con su estado |
| `accion.html` | Detalle de una accion |
| `recompensas.html` | Catalogo de premios |
| `mis-canjes.html` | Codigos canjeados |
| `perfil.html` | Saldo de puntos e historial |
| `admin/pendientes.html` | Cola de moderacion |
| `admin/revisar.html` | Aprobar o rechazar una accion |
| `admin/recompensas.html` | Alta y listado de premios |
| `admin/dashboard.html` | Estadisticas y ranking |

## Estructura

```
frontend/
├── index.html
├── login.html
├── registro.html
├── nueva-accion.html
├── mis-acciones.html
├── accion.html
├── recompensas.html
├── mis-canjes.html
├── perfil.html
├── admin/
│   ├── pendientes.html
│   ├── revisar.html
│   ├── recompensas.html
│   └── dashboard.html
├── css/
│   ├── main.css
│   ├── reset.css
│   ├── variables.css
│   ├── base.css
│   ├── layout.css
│   ├── componentes.css
│   └── paginas.css
└── assets/img/
    └── placeholder.jpg
```

`main.css` importa el resto en orden. Cada pagina enlaza unicamente `main.css`.

## Como verlo

Abrir `frontend/index.html` en el navegador, o usar la extension Live Server de VS Code.

Para probar la vista movil: F12 y activar el modo dispositivo.

## Paleta

| Variable | Valor | Uso |
|---|---|---|
| `--verde` | `#2e7d32` | Color principal |
| `--amarillo` | `#f9a825` | Estado pendiente |
| `--rojo` | `#c62828` | Estado rechazado |
| `--fondo` | `#f5f5f5` | Fondo general |

## Proximos pasos

1. API REST con Node y Express
2. Base de datos MySQL
3. JavaScript de integracion
