# CiudadActiva — Planificación de Proyecto

> **Materia:** _(completar)_
> **Alumno/a:** _(completar)_
> **Fecha de entrega:** _(completar)_
> **Stack:** HTML + CSS + JavaScript (vanilla) · API REST · MySQL

---

## 1. Resumen del proyecto

Aplicación web mobile-first para un municipio donde los vecinos publican **buenas acciones** hechas por la ciudad (limpiar una plaza, pintar un mural, reciclar, reparar un banco, etc.), adjuntando **fotos o videos como prueba**.

Un **administrador municipal** revisa cada publicación y la aprueba o rechaza. Cada acción aprobada otorga **puntos** al vecino, que luego se **canjean por beneficios**: descuentos en comercios adheridos, entradas de cine, pases de colectivo, etc.

**Objetivo del sistema:** incentivar el cuidado del espacio público con un sistema de recompensas verificable.

---

## 2. Aclaración importante sobre "web estática"

Esto vale la pena tenerlo claro desde el día 1, porque afecta toda la arquitectura:

- **Frontend estático** = HTML, CSS y JS que el navegador descarga tal cual, sin un framework que renderice en el servidor (sin Next.js, sin React SSR). Esto **sí** se puede cumplir.
- Pero una app con usuarios, subida de archivos y base de datos **necesita un backend**. Un sitio 100% estático no puede hablar con MySQL: las credenciales quedarían expuestas en el JS del navegador.

**Solución:** el frontend es estático (cumple la consigna) y se comunica por `fetch()` con una **API REST propia**. La API es el único que toca MySQL.

```
[ Navegador: HTML/CSS/JS estático ]
              │  fetch() + JSON
              ▼
[ API REST (PHP o Node/Express) ]
              │  SQL
              ▼
[ MySQL ]  +  [ Carpeta /uploads con fotos y videos ]
```

> **Consejo:** confirmá con el profesor si "web estática" se refiere solo al frontend. Si exige que **todo** sea estático sin backend, el plan B está en la sección 15.

---

## 3. Alcance

### 3.1 MVP (lo que sí o sí tiene que estar)

| # | Funcionalidad |
|---|---|
| 1 | Registro e inicio de sesión de vecinos |
| 2 | Publicar una acción: título, descripción, categoría, ubicación, foto/video |
| 3 | Listado de acciones propias con su estado (pendiente / aprobada / rechazada) |
| 4 | Panel admin: ver pendientes, aprobar o rechazar con motivo |
| 5 | Asignación automática de puntos al aprobar |
| 6 | Catálogo de recompensas y canje con código |
| 7 | Perfil con saldo de puntos e historial |

### 3.2 Deseable (si da el tiempo)

- Feed público de acciones aprobadas (muro de la comunidad)
- Ranking de vecinos (top del mes)
- Mapa con las acciones geolocalizadas (Leaflet + OpenStreetMap, gratis)
- Insignias por cantidad de acciones
- Dashboard admin con estadísticas

### 3.3 Fuera de alcance (decirlo explícitamente en la defensa)

- App nativa iOS/Android
- Pagos reales o integración con comercios reales
- Notificaciones push
- Moderación automática con IA

---

## 4. Actores y roles

| Rol | Qué puede hacer |
|---|---|
| **Visitante** | Ver el feed público y el catálogo de recompensas. Registrarse. |
| **Vecino** (usuario) | Todo lo anterior + publicar acciones, ver sus puntos, canjear recompensas. |
| **Administrador** | Todo lo anterior + moderar acciones, definir puntajes, cargar recompensas, ver estadísticas. |

Se implementa con un campo `rol` en la tabla `usuarios` (`'vecino'` / `'admin'`) y validación **en el backend** (nunca solo ocultando botones en el front).

---

## 5. Stack técnico

### Frontend
- **HTML5** semántico (`<header>`, `<main>`, `<article>`, `<nav>`)
- **CSS3** con variables, Flexbox y Grid. Mobile-first con `@media (min-width: ...)`
- **JavaScript vanilla** (ES6+): `fetch`, `async/await`, módulos, `localStorage` para el token
- Sin librerías pesadas. Opcionales: **Leaflet** (mapa) y **Chart.js** (gráficos del admin)

### Backend — elegí UNA opción

| Opción | A favor | En contra |
|---|---|---|
| **PHP 8 + MySQL** (XAMPP/Laragon) | Es lo estándar en escuelas, se instala en 5 min, `PDO` es simple, subir archivos es trivial con `$_FILES` | Sintaxis distinta a la que ya sabés |
| **Node.js + Express + MySQL2** | Mismo lenguaje que el front, `multer` para archivos, más parecido a lo que ya usás con Next | Hay que explicar npm, `node_modules`, correr dos servidores |

> **Recomendación:** si venís de Next.js, **Node + Express** te va a costar menos y podés reusar conocimiento. Si el profesor solo tiene XAMPP en las máquinas del colegio, andá a **PHP**. Ambos cumplen igual.

### Base de datos
- **MySQL 8** (o MariaDB). Gestión con **phpMyAdmin** o **MySQL Workbench**.

### Herramientas
- **Git + GitHub** (aunque sea uno solo, muestra proceso y suma en la nota)
- **VS Code** + extensión Live Server
- **Postman** o **Thunder Client** para probar la API antes de tocar el front
- **draw.io** para el DER y los diagramas

---

## 6. Modelo de datos

### 6.1 Entidades

```
usuarios ──1:N──> acciones ──N:1──> categorias
    │                 │
    │                 └──1:N──> evidencias
    │
    ├──1:N──> canjes ──N:1──> recompensas
    └──1:N──> movimientos_puntos
```

### 6.2 Script SQL

```sql
CREATE DATABASE ciudad_activa CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE ciudad_activa;

-- ─────────────── USUARIOS ───────────────
CREATE TABLE usuarios (
  id            INT AUTO_INCREMENT PRIMARY KEY,
  nombre        VARCHAR(80)  NOT NULL,
  apellido      VARCHAR(80)  NOT NULL,
  email         VARCHAR(120) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,          -- NUNCA la contraseña en texto plano
  dni           VARCHAR(15)  UNIQUE,
  rol           ENUM('vecino','admin') NOT NULL DEFAULT 'vecino',
  puntos        INT NOT NULL DEFAULT 0,          -- saldo actual (cache)
  activo        BOOLEAN NOT NULL DEFAULT TRUE,
  creado_en     TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ─────────────── CATEGORÍAS ───────────────
CREATE TABLE categorias (
  id              INT AUTO_INCREMENT PRIMARY KEY,
  nombre          VARCHAR(60) NOT NULL UNIQUE,   -- Limpieza, Reciclaje, Arbolado...
  descripcion     VARCHAR(255),
  puntos_sugeridos INT NOT NULL DEFAULT 10,
  icono           VARCHAR(50)
);

-- ─────────────── ACCIONES ───────────────
CREATE TABLE acciones (
  id              INT AUTO_INCREMENT PRIMARY KEY,
  usuario_id      INT NOT NULL,
  categoria_id    INT NOT NULL,
  titulo          VARCHAR(120) NOT NULL,
  descripcion     TEXT NOT NULL,
  direccion       VARCHAR(200),
  latitud         DECIMAL(10,8),
  longitud        DECIMAL(11,8),
  estado          ENUM('pendiente','aprobada','rechazada') NOT NULL DEFAULT 'pendiente',
  puntos_otorgados INT NOT NULL DEFAULT 0,
  motivo_rechazo  VARCHAR(255),
  revisada_por    INT NULL,
  revisada_en     DATETIME NULL,
  creado_en       TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (usuario_id)   REFERENCES usuarios(id),
  FOREIGN KEY (categoria_id) REFERENCES categorias(id),
  FOREIGN KEY (revisada_por) REFERENCES usuarios(id),
  INDEX idx_estado (estado),
  INDEX idx_usuario (usuario_id)
);

-- ─────────────── EVIDENCIAS (fotos/videos) ───────────────
CREATE TABLE evidencias (
  id          INT AUTO_INCREMENT PRIMARY KEY,
  accion_id   INT NOT NULL,
  tipo        ENUM('imagen','video') NOT NULL,
  ruta        VARCHAR(255) NOT NULL,   -- se guarda la RUTA, no el archivo
  tamano_kb   INT,
  creado_en   TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (accion_id) REFERENCES acciones(id) ON DELETE CASCADE
);

-- ─────────────── RECOMPENSAS ───────────────
CREATE TABLE recompensas (
  id             INT AUTO_INCREMENT PRIMARY KEY,
  nombre         VARCHAR(120) NOT NULL,
  descripcion    TEXT,
  comercio       VARCHAR(120),           -- "Cine Rex", "Heladería La Esquina"
  costo_puntos   INT NOT NULL,
  stock          INT NOT NULL DEFAULT 0,
  imagen         VARCHAR(255),
  activa         BOOLEAN NOT NULL DEFAULT TRUE,
  vence_en       DATE
);

-- ─────────────── CANJES ───────────────
CREATE TABLE canjes (
  id             INT AUTO_INCREMENT PRIMARY KEY,
  usuario_id     INT NOT NULL,
  recompensa_id  INT NOT NULL,
  puntos_gastados INT NOT NULL,
  codigo         VARCHAR(20) NOT NULL UNIQUE,   -- ej: CA-8F3K2P
  estado         ENUM('vigente','usado','vencido') DEFAULT 'vigente',
  creado_en      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (usuario_id)    REFERENCES usuarios(id),
  FOREIGN KEY (recompensa_id) REFERENCES recompensas(id)
);

-- ─────────────── MOVIMIENTOS DE PUNTOS (auditoría) ───────────────
CREATE TABLE movimientos_puntos (
  id          INT AUTO_INCREMENT PRIMARY KEY,
  usuario_id  INT NOT NULL,
  tipo        ENUM('ingreso','egreso') NOT NULL,
  cantidad    INT NOT NULL,
  concepto    VARCHAR(160) NOT NULL,
  accion_id   INT NULL,
  canje_id    INT NULL,
  creado_en   TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
);
```

**Por qué la tabla `movimientos_puntos`:** el campo `usuarios.puntos` es solo el saldo rápido. Los movimientos dan trazabilidad: siempre podés reconstruir de dónde salió cada punto. Es un detalle que suma mucho en la defensa del proyecto.

### 6.3 Datos de prueba

```sql
INSERT INTO categorias (nombre, descripcion, puntos_sugeridos) VALUES
('Limpieza',    'Juntar residuos en espacios públicos', 15),
('Reciclaje',   'Separación y entrega en puntos verdes', 10),
('Arbolado',    'Plantación y cuidado de árboles',       25),
('Mantenimiento','Reparación de mobiliario urbano',      30),
('Mural',       'Arte urbano autorizado',                40);

INSERT INTO recompensas (nombre, comercio, costo_puntos, stock) VALUES
('2x1 en entradas',      'Cine Rex',            120, 50),
('20% off en la compra', 'Librería Central',     80, 30),
('Café gratis',          'Bar La Plaza',         50, 100);
```

---

## 7. API REST

**Base URL:** `/api`
**Formato:** JSON. **Auth:** header `Authorization: Bearer <token>`

### Autenticación
| Método | Endpoint | Descripción | Auth |
|---|---|---|---|
| POST | `/auth/registro` | Crear cuenta | — |
| POST | `/auth/login` | Devuelve token + datos del usuario | — |
| GET | `/auth/perfil` | Datos del usuario logueado | Sí |

### Acciones
| Método | Endpoint | Descripción | Auth |
|---|---|---|---|
| GET | `/acciones` | Feed público (solo aprobadas). Filtros: `?categoria=&page=` | — |
| GET | `/acciones/mias` | Mis acciones con su estado | Vecino |
| GET | `/acciones/:id` | Detalle con evidencias | — |
| POST | `/acciones` | Crear acción (`multipart/form-data` con archivos) | Vecino |
| GET | `/acciones/pendientes` | Cola de moderación | Admin |
| PATCH | `/acciones/:id/aprobar` | Body: `{ puntos }` | Admin |
| PATCH | `/acciones/:id/rechazar` | Body: `{ motivo }` | Admin |

### Recompensas y canjes
| Método | Endpoint | Descripción | Auth |
|---|---|---|---|
| GET | `/recompensas` | Catálogo activo | — |
| POST | `/recompensas` | Crear recompensa | Admin |
| POST | `/canjes` | Body: `{ recompensa_id }` → devuelve código | Vecino |
| GET | `/canjes/mios` | Mis canjes y códigos | Vecino |

### Otros
| Método | Endpoint | Descripción |
|---|---|---|
| GET | `/categorias` | Lista de categorías |
| GET | `/ranking` | Top 10 usuarios por puntos |
| GET | `/admin/stats` | Métricas para el dashboard |

### Ejemplos de respuesta

**`POST /api/auth/login` — 200**
```json
{
  "ok": true,
  "token": "eyJhbGciOi...",
  "usuario": { "id": 4, "nombre": "Lucía", "rol": "vecino", "puntos": 145 }
}
```

**Error — 422**
```json
{ "ok": false, "error": "Puntos insuficientes", "codigo": "SALDO_INSUFICIENTE" }
```

> Mantené **siempre** la misma forma de respuesta (`ok`, `data` / `error`). Hace el JS del front mucho más simple.

---

## 8. Subida de fotos y videos

Es la parte más delicada del proyecto. Reglas:

1. **Los archivos NO van a MySQL.** Se guardan en `/uploads/` y en la base solo queda la ruta (`evidencias.ruta`).
2. **Nombre generado por el servidor**, nunca el original: `ev_<accionId>_<uuid>.jpg`. Evita colisiones y que alguien suba `../../index.php`.
3. **Validar en el servidor**, no solo en el front:
   - Extensiones permitidas: `jpg, jpeg, png, webp, mp4, webm`
   - Tamaño máximo: **5 MB** imágenes / **25 MB** videos
   - Verificar el **MIME type real** (`finfo` en PHP, `file-type` en Node), porque la extensión se falsifica fácil
4. **Comprimir en el cliente antes de subir.** Desde el celular una foto pesa 4–8 MB. Con un `<canvas>` la redimensionás a 1280px de ancho y baja a ~300 KB. Mejora enormemente la experiencia con datos móviles.
5. Cámara directa desde el celu:
   ```html
   <input type="file" accept="image/*" capture="environment">
   ```
6. Preview antes de enviar con `URL.createObjectURL(file)`.
7. Límite de **3 evidencias por acción**.

**Envío desde el front:**
```js
const fd = new FormData();
fd.append('titulo', titulo);
fd.append('categoria_id', catId);
archivos.forEach(f => fd.append('evidencias[]', f));

await fetch('/api/acciones', {
  method: 'POST',
  headers: { 'Authorization': `Bearer ${token}` }, // sin Content-Type: lo pone el browser
  body: fd
});
```

---

## 9. Flujos principales

### 9.1 Publicar una acción
```
Vecino → [Nueva acción] → completa formulario → saca/elige foto
       → preview + compresión → POST /api/acciones
       → estado "pendiente" → notificación en pantalla
       → aparece en "Mis acciones" con badge amarillo
```

### 9.2 Moderación
```
Admin → Panel → cola de pendientes (más viejas primero)
      → abre detalle, ve evidencias en grande
      → APROBAR: define puntos (sugeridos por categoría, editable)
                 → transacción: acciones.estado='aprobada'
                                usuarios.puntos += X
                                INSERT movimientos_puntos
      → RECHAZAR: escribe motivo → el vecino lo ve en su lista
```

### 9.3 Canje
```
Vecino → Catálogo → elige recompensa
       → validación backend: saldo >= costo && stock > 0
       → transacción: usuarios.puntos -= costo
                      recompensas.stock -= 1
                      INSERT canjes (código único)
                      INSERT movimientos_puntos (egreso)
       → muestra el código para presentar en el comercio
```

> **Las tres operaciones de puntos van dentro de una transacción SQL** (`START TRANSACTION` / `COMMIT` / `ROLLBACK`). Si falla algo en el medio, no queda el saldo descontado sin canje generado. Mencionarlo en la defensa suma.

---

## 10. Pantallas (mobile-first)

| # | Pantalla | Contenido |
|---|---|---|
| 1 | **Login / Registro** | Logo, form, link entre ambas |
| 2 | **Inicio (feed)** | Cards de acciones aprobadas: foto, autor, categoría, puntos |
| 3 | **Nueva acción** | Form + cámara + preview. Botón flotante `+` |
| 4 | **Mis acciones** | Lista con badges de estado y motivo de rechazo si aplica |
| 5 | **Recompensas** | Grid de cards con costo. Deshabilitadas si no alcanza el saldo |
| 6 | **Mis canjes** | Códigos con estado |
| 7 | **Perfil** | Avatar, puntos grandes, historial de movimientos, logout |
| 8 | **Admin — Pendientes** | Cola con contador de pendientes |
| 9 | **Admin — Detalle** | Evidencias grandes + aprobar/rechazar |
| 10 | **Admin — Dashboard** | Totales, gráfico por categoría |

### Navegación
Barra inferior fija de 4 ítems: **Inicio · Publicar · Recompensas · Perfil**. Para el admin se agrega un quinto o se usa una ruta aparte.

### Guía visual rápida
```css
:root {
  --verde:  #2E7D32;   /* identidad: ciudad, medio ambiente */
  --verde-claro: #A5D6A7;
  --gris-900: #212121;
  --gris-100: #F5F5F5;
  --amarillo: #FBC02D; /* pendiente */
  --rojo: #D32F2F;     /* rechazado */
  --radio: 12px;
}
```
- Áreas táctiles de mínimo **44×44 px**
- Tipografía base 16px (menos provoca zoom automático en iOS)
- Breakpoints: base móvil → `768px` tablet → `1024px` escritorio

---

## 11. Estructura de carpetas

```
ciudad-activa/
├── frontend/
│   ├── index.html              # feed
│   ├── login.html
│   ├── registro.html
│   ├── nueva-accion.html
│   ├── mis-acciones.html
│   ├── recompensas.html
│   ├── perfil.html
│   ├── admin/
│   │   ├── pendientes.html
│   │   └── dashboard.html
│   ├── css/
│   │   ├── variables.css
│   │   ├── base.css            # reset + tipografía
│   │   ├── componentes.css     # cards, botones, badges
│   │   └── paginas.css
│   ├── js/
│   │   ├── api.js              # wrapper de fetch + token
│   │   ├── auth.js             # login, logout, guard de rutas
│   │   ├── acciones.js
│   │   ├── recompensas.js
│   │   ├── admin.js
│   │   └── utils.js            # fechas, validaciones, compresión
│   └── assets/img/
│
├── backend/
│   ├── config/db.php           # (o db.js)
│   ├── routes/
│   ├── controllers/
│   ├── middleware/auth.php
│   └── uploads/                # ⚠️ en .gitignore
│
├── db/
│   ├── schema.sql
│   └── seed.sql
│
├── docs/
│   ├── DER.png
│   ├── wireframes.pdf
│   └── manual-usuario.pdf
│
└── README.md
```

**Patrón clave — `api.js`:** un solo archivo que centraliza `fetch`, inyecta el token y maneja errores. El resto del JS solo llama `api.get('/acciones')`. Evita repetir código en cada página.

---

## 12. Reglas de negocio

### Puntos
- Cada categoría tiene puntaje sugerido; el admin puede ajustarlo al aprobar (mín. 5, máx. 100)
- Los puntos se acreditan **solo al aprobar**, nunca al publicar
- Límite: **3 acciones por usuario por día** (evita spam)
- Los puntos **no vencen** (simplifica el MVP)

### Antifraude (mencionalo aunque no lo implementes todo)
- Toda acción pasa por revisión humana
- Se guarda fecha/hora de la publicación
- El admin ve si el usuario ya publicó algo parecido (mismo lugar, mismo día)
- Posible extra: comparar coordenadas GPS de acciones recientes del mismo usuario

### Canjes
- El código se genera con formato `CA-XXXXXX` (6 caracteres alfanuméricos)
- Un canje no se puede revertir
- El comercio marca el código como `usado` (versión simple: lo hace el admin)

---

## 13. Seguridad

Lista concreta, ordenada por importancia:

1. **Contraseñas hasheadas** con `password_hash()` (PHP) o `bcrypt` (Node). Jamás texto plano.
2. **Consultas preparadas** siempre (`PDO::prepare` / placeholders en mysql2). Previene **SQL injection** — es el punto que más preguntan los profesores.
3. **Validación duplicada:** en el front para la experiencia, en el backend por seguridad. El front se salta con F12.
4. **Autorización por rol en el servidor.** Ocultar el botón de admin no alcanza: si `/api/acciones/5/aprobar` no chequea el rol, cualquiera lo llama desde la consola.
5. **Escapar la salida** al insertar contenido de usuario en el DOM: usá `textContent`, no `innerHTML`. Previene **XSS**.
6. **Validar archivos subidos** (ver sección 8).
7. **CORS** configurado solo para el origen del frontend.
8. **`.gitignore`** con credenciales, `/uploads/` y `node_modules/`.

---

## 14. Plan de trabajo

Estimado en **8 semanas**. Ajustá según tu fecha de entrega.

| Semana | Objetivo | Entregable |
|---|---|---|
| **1** | Análisis y diseño | DER, wireframes de las 10 pantallas, definición de alcance |
| **2** | Base de datos + entorno | `schema.sql` corriendo, datos de prueba, repo Git inicializado |
| **3** | API: auth + CRUD acciones | Endpoints probados en Postman. **Sin tocar el front todavía** |
| **4** | API: uploads, moderación, puntos, canjes | API completa y documentada |
| **5** | Front: maquetado | HTML + CSS de todas las pantallas, responsive, con datos falsos |
| **6** | Front: integración | `api.js`, login funcionando, publicar acción real con foto |
| **7** | Panel admin + recompensas | Flujo completo punta a punta |
| **8** | Pulido, testing y documentación | README, manual, presentación, deploy |

### Orden recomendado dentro de cada etapa
> **API primero, front después.** Si maquetás todo y recién ahí armás la API, vas a tener que rehacer el JS. Con la API andando en Postman, el front es solo pintar datos.

### Hitos de control
- [ ] **Fin semana 2:** puedo hacer `SELECT` y ver datos de prueba
- [ ] **Fin semana 4:** puedo crear una acción con foto desde Postman y aprobarla
- [ ] **Fin semana 6:** puedo registrarme y publicar desde el celular
- [ ] **Fin semana 7:** flujo completo: publico → admin aprueba → gano puntos → canjeo

---

## 15. Riesgos y planes B

| Riesgo | Plan B |
|---|---|
| El profesor exige **todo estático** sin backend | Simular la API con un `db.json` + `localStorage`. Se pierde persistencia real, pero el flujo se demuestra igual. Documentá que la migración a MySQL está diseñada (mostrás el `schema.sql`) |
| No llego con los videos | Solo imágenes en el MVP. Dejá la tabla `evidencias` ya preparada con el campo `tipo` |
| Subida de archivos falla en el servidor de la escuela | Probá con archivos chicos primero y revisá `upload_max_filesize` / `post_max_size` en `php.ini` |
| Me quedo sin tiempo | Prioridad de corte: mapa → ranking → dashboard → feed público. El core (publicar/aprobar/canjear) es intocable |
| Pérdida de archivos | Commit a GitHub al final de cada jornada de trabajo |

---

## 16. Checklist de entrega

**Código**
- [ ] Todas las funcionalidades del MVP operativas
- [ ] Responsive verificado en celular real (no solo DevTools)
- [ ] Sin `console.log` ni código comentado de prueba
- [ ] Nombres de variables en un solo idioma, consistentes

**Base de datos**
- [ ] `schema.sql` + `seed.sql` exportados y en el repo
- [ ] DER impreso o en PDF

**Documentación**
- [ ] `README.md`: qué es, cómo instalarlo, cómo correrlo, usuarios de prueba
- [ ] Manual de usuario con capturas
- [ ] Documentación de la API (tabla de endpoints)

**Presentación**
- [ ] Datos de prueba cargados (10+ acciones, 5 recompensas, 2 usuarios + 1 admin)
- [ ] Demo ensayada del flujo completo en menos de 5 minutos
- [ ] Respuestas preparadas para: *¿por qué necesitás un backend?*, *¿cómo evitás SQL injection?*, *¿cómo garantizás que no se dupliquen los puntos?*

---

## 17. Primeros tres pasos

1. **Hoy:** crear el repo, la carpeta del proyecto y ejecutar el `schema.sql` de la sección 6.2. Verificar en phpMyAdmin que las 7 tablas existen.
2. **Esta semana:** dibujar los wireframes de las 10 pantallas en papel o Figma. No pases al código sin esto.
3. **Después:** levantar el endpoint `POST /api/auth/registro` y probarlo en Postman. Con ese funcionando, el resto es repetir el patrón.
